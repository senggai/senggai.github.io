@echo off
anytls-client.exe -l 127.0.0.1:1080 -s jp01.shanhai.click:18888 -p e32993ff-5e0f-457b-babe-2cd87aa71a0b -sni jp01.shanhai.click
pause
